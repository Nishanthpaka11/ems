import { useState } from "react";
import './Navbar.css';
import logo from '../logo1.png'; // adjust path as needed
import { Link } from 'react-router-dom';

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const toggleMenu = () => setMenuOpen(prev => !prev);
  
  return (
    <nav className="navbar">
      <div className="logo-container">
        <img src={logo} alt="ISAR Logo" className="logo-image" />
        <h1 className="logo">INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS</h1>
      </div>

      <button className="menu-toggle" onClick={toggleMenu}>☰</button>

      <ul className={`nav-links ${menuOpen ? "active" : ""}`}>
        <li><Link to="/" onClick={() => setMenuOpen(false)}>Home</Link></li>
        <li><Link to="/about" onClick={() => setMenuOpen(false)}>About</Link></li>
        <li><Link to="/courses" onClick={() => setMenuOpen(false)}>Courses</Link></li>
        <li><Link to="/careers" onClick={() => setMenuOpen(false)}>Career</Link></li>
        <li><Link to="/contact" onClick={() => setMenuOpen(false)}>Contact</Link></li>
         <li><Link to="/login" onClick={() => setMenuOpen(false)}>Employee Login</Link></li>
      </ul>
    </nav>
  );
}

export default Navbar;
