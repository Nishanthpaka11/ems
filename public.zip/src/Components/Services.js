import React from "react";
import { Helmet } from 'react-helmet';
import Advanced from  '../o1.png'; // Update with your image path
import Young from  '../o2.png'; // Update with your image path
import Junior from  '../o3.png'; 
import senior from  '../o4.png'; 
import commingsoon from'../s5.png';
import './Services.css';

const Services = () => (
   <section id="services" className="services">
    <h2>DRONE COURSE</h2>
    <p className="starting">
      ISAR is a premier institute providing innovative research and consultancy solutions to empower industries and academia. 
      We specialize in bridging the gap between research and practical applications.
    </p>

    <div className="about-grid">
      <div className="card">
        <img src={Advanced} alt="Young Learners (Kids)" />
        <div className="text">
          <h3>Young Learners (Kids)</h3>
          <p>
           Fun and safe drone introduction! Kids learn basic flight and safety through hands-on activities.
           </p>
        </div>
      </div>
      <div className="card">
        <img src={Young} alt="Junior High Drone Training (Grades 8-10)" />
        <div className="text">
          <h3>Junior High Drone Training (Grades 8-10)</h3>
          <p>
            Unlock the secrets of drone technology! Explore how drones capture amazing data, solve real-world problems, and learn to pilot with confidence.
          </p>
        </div>
      </div>
      
      <div className="card">
        <img src={Junior} alt="Senior High Drone Training (Grades 11-12)" />
        <div className="text">
          <h3>Senior High Drone Training (Grades 11-12)</h3>
          <p>
            Master the art of drone operations! From technical flight skills to real-world applications, this course equips you with the knowledge and abilities needed to succeed in the drone field.
          </p>
        </div>
       </div> 
        <div className="card">
        <img src={senior} alt="Advanced Drone Training(Undergraduate)" />
        <div className="text">
          <h3>Advanced Drone Training(Undergraduate)</h3>
          <p>
           Professional drone training! Master advanced technology and industry-specific applications.
          </p>
        </div>
        </div>
<div className="comingsoon-section">
  <div className="image-overlay-container">
    <img src={commingsoon} alt="Coming Soon" className="full-width-img" />
    <h1 className="coming-soon-overlay">COMING SOON</h1>
  </div>
</div>

</div>
<Helmet>
        <title>INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS</title>
      <meta
      name="description"
      content="Explore ISAR's professional training services in drone technology, robotics engineering, UAV design, and aerospace systems. Hands-on, certified, and student-friendly."
    />
    <meta
      name="keywords"
      content="drone training services, robotics workshop India, aerospace internship, ISAR services, UAV technology, drone training for students"
    />
        {/* Open Graph / Facebook */}
        <meta property="og:title" content="ISAR | Best Drone Training in India" />
        <meta
          property="og:description"
          content="Learn drone flying, aerial survey, and robotics from certified experts at ISAR – Indian Scientific Aerospace and Robotics."
        />
        <meta property="og:image" content="/isar-preview.png" />
        <meta property="og:url" content="https://www.isar.in" />
        <meta property="og:type" content="website" />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="ISAR | Drone Training Institute in India" />
        <meta name="twitter:description" content="Expert drone pilot training in Chennai at ISAR. Join India's top aerospace and robotics institute." />
        <meta name="twitter:image" content="/isar-preview.png" />

        {/* JSON-LD Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "ISAR - Indian Scientific Aerospace and Robotics",
            "image": "https://www.isar.in/isar-preview.png",
            "url": "https://www.isaar.in",
            "telephone": "+91-6374720788",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "339/2 at kurunji Nagar Valayapatti, Mohanur , Namakkal District, Tamil Nadu",
              "addressLocality": "Chennai",
              "addressRegion": "Tamil Nadu",
              "postalCode": "637020",
              "addressCountry": "IN"
            },
            "description": "Top drone training center in India, offering hands-on certification in drone tech, robotics, and aerospace.",
            "sameAs": ["https://www.instagram.com/_isar_25"]
          })}
        </script>
      </Helmet>
  </section>
);

export default Services;

  


