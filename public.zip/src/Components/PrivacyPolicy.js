// components/PrivacyPolicy.js
import React, { useState } from 'react';
import './PrivacyPolicy.css'; // Importing the separate CSS

const PrivacyPolicy = () => {
  const [isOpen, setIsOpen] = useState(false);

  const openModal = () => setIsOpen(true);
  const closeModal = () => setIsOpen(false);

  return (
    <>
      {/* Footer Button */}
      <button className="privacy-button" onClick={openModal}>
        Privacy Policy
      </button>

      {/* Modal */}
      {isOpen && (
        <div className="privacy-modal-overlay" onClick={closeModal}>
          <div className="privacy-modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>Privacy Policy</h2>
            <p>This privacy policy explains how we handle your personal data.</p>

            <h3>1. Data Collection</h3>
            <p>We may collect personal information such as name, email, etc.</p>

            <h3>2. Use of Information</h3>
            <p>We use your data to provide services and respond to your inquiries.</p>

            <h3>3. Cookies</h3>
            <p>Cookies help improve your experience. You can manage cookie settings in your browser.</p>

            <h3>4. Third-Party Services</h3>
            <p>We use analytics tools that may collect anonymous usage data.</p>

            <h3>5. Contact</h3>
            <p>
              If you have questions, contact us at{' '}
              <a href="mailto:contact@isaar.in">contact@isaar.in</a>.
            </p>

            <button className="privacy-close-button" onClick={closeModal}>
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default PrivacyPolicy;
