import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import './TaskSection.css';

const TaskSection = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState({ title: '', description: '' });
  const [message, setMessage] = useState('');
  const token = localStorage.getItem('token');

  // Fetch tasks from backend
  const fetchTasks = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/tasks', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTasks(res.data);
    } catch (err) {
      console.error('Error fetching tasks:', err);
    }
  }, [token]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  // Add new task
  const handleAddTask = async (e) => {
    e.preventDefault();
    if (!newTask.title || !newTask.description) {
      setMessage('Title and Description are required');
      return;
    }
    try {
      await axios.post('http://localhost:5000/api/tasks', newTask, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setMessage('Task added successfully');
      setNewTask({ title: '', description: '' });
      fetchTasks();
    } catch (err) {
      console.error('Add task error:', err);
      setMessage('Failed to add task');
    }
  };

  // Update task status
  const handleStatusChange = async (id, status) => {
    try {
      await axios.put(
        `http://localhost:5000/api/tasks/${id}`,
        { status },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      fetchTasks();
    } catch (err) {
      console.error('Update task error:', err);
    }
  };

  return (
   <div className="task-section">
  <h3>Task Tracking</h3>

  {message && <p className="task-message">{message}</p>}

  <form onSubmit={handleAddTask} className="task-form">
    <input
      type="text"
      placeholder="Task Title"
      value={newTask.title}
      onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
      required
    />
    <input
      type="text"
      placeholder="Task Description"
      value={newTask.description}
      onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
      required
    />
    <button type="submit">Add Task</button>
  </form>

  {/* Desktop Table */}
  <table className="task-table desktop-only">
    <thead>
      <tr>
        <th>Title</th>
        <th>Description</th>
        <th>Status</th>
        <th>Change</th>
        <th>Created</th>
        <th>Completed</th>
      </tr>
    </thead>
    <tbody>
      {tasks.map((task) => (
        <tr key={task.id}>
          <td>{task.title}</td>
          <td>{task.description}</td>
          <td>{task.status}</td>
          <td>
            <select
              value={task.status}
              onChange={(e) => handleStatusChange(task.id, e.target.value)}
            >
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>
          </td>
          <td>{new Date(task.created_at).toLocaleString()}</td>
          <td>
            {task.completed_at ? new Date(task.completed_at).toLocaleString() : '-'}
          </td>
        </tr>
      ))}
    </tbody>
  </table>

  {/* Mobile Card View */}
  <div className="task-cards mobile-only">
    {tasks.map((task) => (
      <div key={task.id} className="task-card">
        <p><strong>Title:</strong> {task.title}</p>
        <p><strong>Description:</strong> {task.description}</p>
        <p><strong>Status:</strong> {task.status}</p>
        <p>
          <strong>Change:</strong>
          <select
            value={task.status}
            onChange={(e) => handleStatusChange(task.id, e.target.value)}
          >
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
          </select>
        </p>
        <p><strong>Created:</strong> {new Date(task.created_at).toLocaleString()}</p>
        <p><strong>Completed:</strong> {task.completed_at ? new Date(task.completed_at).toLocaleString() : '-'}</p>
      </div>
    ))}
  </div>
</div>
  );
};

export default TaskSection;
