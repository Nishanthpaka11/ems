import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import moment from 'moment-timezone';
import './EmployeeDashboard.css';
import { useNavigate } from 'react-router-dom';
import LeaveSection from './LeaveSection';
import ProfileSection from './ProfileSection';
import TaskSection from './TaskSection';
import ChangePasswordSection from './ChangePasswordSection';
import WorkingHoursSection from './WorkingHoursSection';

function EmployeeDashboard() {
  const token = localStorage.getItem('token');
  const [status, setStatus] = useState({ punch_in: null, punch_out: null });
  const [clock, setClock] = useState(new Date());
  const [error, setError] = useState('');
  const [ip, setIp] = useState('');
  const [workDuration, setWorkDuration] = useState('00h 00m 00s');
  const navigate = useNavigate();

  useEffect(() => {
    const interval = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchStatus = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/attendance/status', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStatus(res.data);
      setError('');
    } catch (err) {
      console.error('Status fetch failed:', err);
      setError('Unable to fetch status. Please login again.');
    }
  }, [token]);

  const fetchIP = useCallback(async () => {
    try {
      const res = await axios.get('https://api.ipify.org?format=json');
      setIp(res.data.ip);
    } catch (err) {
      console.error('IP fetch failed:', err);
      setIp('Unavailable');
    }
  }, []);

  useEffect(() => {
    fetchStatus();
    fetchIP();
    const interval = setInterval(fetchStatus, 10000);
    return () => clearInterval(interval);
  }, [fetchStatus, fetchIP]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  useEffect(() => {
    let interval = null;
    if (status.punch_in && !status.punch_out) {
      interval = setInterval(() => {
        const start = moment.tz(status.punch_in, 'Asia/Kolkata');
        const now = moment().tz('Asia/Kolkata');
        const duration = moment.duration(now.diff(start));
        const hours = String(duration.hours()).padStart(2, '0');
        const minutes = String(duration.minutes()).padStart(2, '0');
        const seconds = String(duration.seconds()).padStart(2, '0');
        setWorkDuration(`${hours}h ${minutes}m ${seconds}s`);
      }, 1000);
    } else {
      setWorkDuration('00h 00m 00s');
    }
    return () => clearInterval(interval);
  }, [status.punch_in, status.punch_out]);

  const calculateWorkingHours = () => {
    if (status.punch_in && status.punch_out) {
      const punchIn = moment.tz(status.punch_in, 'Asia/Kolkata');
      const punchOut = moment.tz(status.punch_out, 'Asia/Kolkata');
      const duration = moment.duration(punchOut.diff(punchIn));
      const hours = Math.floor(duration.asHours());
      const minutes = duration.minutes();
      return `${hours}h ${minutes}m`;
    }
    return 'N/A';
  };

  const handleDownloadAttendance = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/attendance/export', {
        headers: { Authorization: `Bearer ${token}` },
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'attendance.csv');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('Attendance download error:', err);
      alert('Failed to download attendance report');
    }
  };

  const handleDownloadLeaves = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/leaves/export', {
        headers: { Authorization: `Bearer ${token}` },
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'leaves.csv');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('Leaves download error:', err);
      alert('Failed to download leave report');
    }
  };

  const formatTime = (timestamp) => {
    return moment.tz(timestamp, 'Asia/Kolkata').format('hh:mm A');
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h2>Welcome Employee</h2>
        <div className="clock">{clock.toLocaleTimeString()}</div>
        <button onClick={handleLogout} className="logout-btn">Logout</button>
      </div>

      <div className="dashboard-card">
        <p><strong>Your IP:</strong> {ip || 'Fetching...'}</p>

        <div className="punch-status">
          <h3>Attendance Status (Today)</h3>

          {!status.punch_in && (
            <p className="text-yellow-600 font-medium">❗ You have not punched in yet.</p>
          )}

          {status.punch_in && !status.punch_out && (
            <p className="text-green-600 font-medium">
              ✅ You punched in at {formatTime(status.punch_in)}
            </p>
          )}

          {status.punch_in && status.punch_out && (
            <p className="text-blue-600 font-medium">
              ✅ You punched in at {formatTime(status.punch_in)} and punched out at {formatTime(status.punch_out)}
            </p>
          )}
        </div>

        {status.punch_in && !status.punch_out && (
          <div className="live-timer">
            <p><strong>Live Work Timer:</strong> {workDuration}</p>
          </div>
        )}

        {status.punch_in && status.punch_out && (
          <p><strong>Total Work Duration:</strong> {calculateWorkingHours()}</p>
        )}

        <div className="download-buttons">
          <h3>Download Reports</h3>
          <button onClick={handleDownloadAttendance}>Download Attendance (CSV)</button>
          <button onClick={handleDownloadLeaves}>Download Leaves (CSV)</button>
        </div>

        {error && <p className="error">{error}</p>}
      </div>

      <WorkingHoursSection />
      <ProfileSection />
      <ChangePasswordSection />
      <TaskSection />
      <LeaveSection token={token} />
    </div>
  );
}

export default EmployeeDashboard;
