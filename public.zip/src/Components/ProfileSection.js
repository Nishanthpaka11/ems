import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ProfileSection.css'; // Custom CSS

function ProfileSection() {
  const [profile, setProfile] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('/api/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProfile(res.data);
      } catch (err) {
        setError('Failed to load profile. Please log in again.');
        console.error('Failed to load profile:', err);
      }
    };
    fetchProfile();
  }, []);

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        '/api/profile',
        {
          name: profile.name,
          phone: profile.phone,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setMessage('Profile updated successfully');
      setError('');
    } catch (err) {
      setError('Update failed. Please try again.');
      console.error('Update failed:', err);
    }
  };

  if (!profile) return <p>Loading profile...</p>;

  return (
    <div className="profile-section">
      <h3>👤 Profile Management</h3>

      {error && <p className="error-msg">{error}</p>}
      {message && <p className="success-msg">{message}</p>}

      <div className="profile-field">
        <label>Employee ID:</label>
        <input type="text" value={profile.employee_id} disabled />
      </div>

      <div className="profile-field">
        <label>Email:</label>
        <input type="text" value={profile.email} disabled />
      </div>

      <div className="profile-field">
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={profile.name}
          onChange={handleChange}
        />
      </div>

      <div className="profile-field">
        <label>Phone:</label>
        <input
          type="text"
          name="phone"
          value={profile.phone || ''}
          onChange={handleChange}
        />
      </div>

      <button className="save-button" onClick={handleSave}>
        Save Changes
      </button>
    </div>
  );
}

export default ProfileSection;
