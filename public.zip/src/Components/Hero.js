import { useState } from 'react';
import { Helmet } from 'react-helmet';
import './Hero.css';
import Spline from '@splinetool/react-spline';
import { Link } from 'react-router-dom';


// Import gallery images and video
import gallery1 from '../Screenshot 2025-05-27 124214.png';
import gallery2 from '../Screenshot 2025-05-27 124242.png';
import gallery3 from '../Screenshot 2025-05-27 124300.png';
import gallery4 from '../Screenshot 2025-05-27 124339.png';
import gallery5 from '../Screenshot 2025-05-27 124339.png';
import gallery6 from '../Screenshot 2025-05-27 124356.png';
import gallery7 from '../Screenshot 2025-05-27 124412.png';
//import video from '../assets/video.mp4';

const Hero = ({ setCurrentSection }) => {
  

  const galleryItems = [
    { type: 'image', src: gallery1 },
    { type: 'image', src: gallery2 },
    { type: 'image', src: gallery3 },
    { type: 'image', src: gallery4 },
    { type: 'image', src: gallery5 },
    { type: 'image', src: gallery6 },
    { type: 'image', src: gallery7 },
   // { type: 'video', src: video }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? galleryItems.length - 1 : prevIndex - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === galleryItems.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <>
  
          <Helmet>
        <title>INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS</title>
        <meta
          name="description"
          content="Join ISAR – the top drone training center in India offering expert-led courses in drone technology, aerospace, and robotics. Enroll in Chennai’s leading drone institute today. drone training. drone training . "
        />
        <meta
          name="keywords"
          content="best drone training center in Chennai, drone training in India, drone pilot certification, aerospace training, ISAR"
        />

        {/* Open Graph / Facebook */}
        <meta property="og:title" content="ISAR | Best Drone Training in India" />
        <meta
          property="og:description"
          content="Learn drone flying, aerial survey, and robotics from certified experts at ISAR – Indian Scientific Aerospace and Robotics."
        />
        <meta property="og:image" content="/isar-preview.png" />
        <meta property="og:url" content="https://www.isar.in" />
        <meta property="og:type" content="website" />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="ISAR | Drone Training Institute in India" />
        <meta name="twitter:description" content="Expert drone pilot training in Chennai at ISAR. Join India's top aerospace and robotics institute." />
        <meta name="twitter:image" content="/isar-preview.png" />

        {/* JSON-LD Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "ISAR - Indian Scientific Aerospace and Robotics",
            "image": "https://www.isar.in/isar-preview.png",
            "url": "https://www.isaar.in",
            "telephone": "+91-6374720788",
            "logo": "https://www.isaar.in/logo1.png",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "339/2 at kurunji Nagar Valayapatti, Mohanur , Namakkal District, Tamil Nadu",
              "addressLocality": "Chennai",
              "addressRegion": "Tamil Nadu",
              "postalCode": "637020",
              "addressCountry": "IN"
            },
            "description": "Top drone training center in India, offering hands-on certification in drone tech, robotics, and aerospace.",
            "sameAs": ["https://www.instagram.com/_isar_25"]
          })}
        </script>
      </Helmet>
      <section id="hero" className="hero">
          <div className="hero-animation">
          <Spline className='spline' scene="https://prod.spline.design/9TLmRe8so0bDROmV/scene.splinecode" />
         <div className="hero-content">
          <h1>Welcome to ISAR</h1>
          <h3>Explore the Future of Drone Technology</h3>
          </div>
          <div className="contact-button-wrapper">
          <Link to="/contact" className="contact-btn">
              Explore our Courses
          </Link>

          </div>
          <p className="hero-description">
            We specialize in drone research, pilot training, aerial surveys, and industrial solutions.
            Discover how our technology is revolutionizing industries.
          </p>
        </div>
      </section>
      
        <section className="cta-section">
        <h2>Start Your Drone Journey Today</h2>
          <p>
           Join the growing drone industry with India’s most trusted training and technology partner. 
            Contact us now or explore our programs!
           </p>
          <Link to="/contact" className="con-btn">
               Get in touch
           </Link>

      </section> 
    <section className="testimonial-section">
  <div className="testimonial-container">
    <h2 className="testimonial-title">💬 What Our Students Say</h2>
    <blockquote className="testimonial-quote">
      <p>
        “ISAR gave me the skills and confidence to start my own drone mapping business. 
        The trainers were excellent!”
      </p>
      <footer>— <strong>Rohit Sharma</strong></footer>
    </blockquote>
  </div>
</section>

  <section className="mission-section">
  <h2 className="mission-title">Our Mission</h2>
  <p className="mission-text">
    At ISAR, our mission is to cultivate skilled drone pilots, push innovation in unmanned aerial systems, and support industries with advanced drone solutions—from agriculture to infrastructure.
  </p>
</section>
   <section className="why-isaar-section">
  <h2 className="why-title">Why Choose ISAR?</h2>
  <ul className="why-list">
    <li>✅ DGCA-Approved Training Curriculum</li>
    <li>✅ Hands-on Flight Experience</li>
    <li>✅ Experienced Instructors & Technicians</li>
    <li>✅ 100% Placement Assistance</li>
  </ul>
</section> 
    <section className="impact-section">
  <h2 className="impact-title">Our Impact</h2>
  <div className="stats">
    <div className="stat-item">
      <strong>500+</strong><br />Pilots Trained
    </div>
    <div className="stat-item">
      <strong>20+</strong><br />Training Locations
    </div>
    <div className="stat-item">
      <strong>50+</strong><br />Industry Projects Completed
    </div>
  </div>
</section>



      {/* Gallery Section */}
      <section className="gallery-section">
        <h1 className="gallery-title">Gallery</h1>
        <div className="gallery-wrapper">
          <button className="gallery-nav left" onClick={handlePrev}>❮</button>
          <div className="gallery-display">
            {galleryItems[currentIndex].type === 'image' ? (
              <img src={galleryItems[currentIndex].src} alt={`Gallery ${currentIndex}`} />
            ) : (
              <video controls>
                <source src={galleryItems[currentIndex].src} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            )}
          </div>
          <button className="gallery-nav right" onClick={handleNext}>❯</button>
        </div>
      </section>
      
    </>
  );
};

export default Hero;
