import './About.css';
import { Helmet } from 'react-helmet';
import journeyImage from  '../s6.jpg'; 
import valuesImage from  '../s2.png';
import mission from  '../s3.png'; 

const About = () => (
<>
  <Helmet>
        <title>INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS</title>
      <meta
      name="description"
      content="Learn about ISAR - Indian Scientific Aerospace and Robotics. We provide certified drone, robotics, and aerospace programs for students in India."
    />
    <meta
      name="keywords"
      content="about ISAR, drone institute India, robotics internship, UAV courses, aerospace education, STEM training"
    />
        {/* Open Graph / Facebook */}
        <meta property="og:title" content="ISAR | Best Drone Training in India" />
        <meta
          property="og:description"
          content="Learn drone flying, aerial survey, and robotics from certified experts at ISAR – Indian Scientific Aerospace and Robotics."
        />
        <meta property="og:image" content="/isar-preview.png" />
        <meta property="og:url" content="https://www.isar.in" />
        <meta property="og:type" content="website" />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="ISAR | Drone Training Institute in India" />
        <meta name="twitter:description" content="Expert drone pilot training in Chennai at ISAR. Join India's top aerospace and robotics institute." />
        <meta name="twitter:image" content="/isar-preview.png" />

        {/* JSON-LD Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "ISAR - Indian Scientific Aerospace and Robotics",
            "image": "https://www.isar.in/isar-preview.png",
            "url": "https://www.isaar.in",
            "telephone": "+91-6374720788",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "339/2 at kurunji Nagar Valayapatti, Mohanur , Namakkal District, Tamil Nadu",
              "addressLocality": "Chennai",
              "addressRegion": "Tamil Nadu",
              "postalCode": "637020",
              "addressCountry": "IN"
            },
            "description": "Top drone training center in India, offering hands-on certification in drone tech, robotics, and aerospace.",
            "sameAs": ["https://www.instagram.com/_isar_25"]
          })}
        </script>
      </Helmet>
  <section className="about-zigzag">
  <div className="zigzag-block left" data-aos="fade-up">
    <img src={mission} alt="Mission" className="zigzag-img" />
    <div className="zigzag-text" data-aos="zoom-in">
      <h3>Our Mission and Vision</h3>
      <p>At INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS, we are dedicated to providing top-tier drone technology training and theoretical knowledge to aspiring individuals. Our goal is to empower students, parents, and undergraduates with the skills needed to excel in the field of drones.</p>
    </div>
  </div>

  <div className="zigzag-block right" data-aos="flip-left">
    <img src={journeyImage} alt="Journey" className="zigzag-img" />
    <div className="zigzag-text" data-aos="slide-up">
      <h3>Our Journey</h3>
      <section className="journey-section">
  <h2 className="section-title">Our Journey</h2>
  <p className="journey-paragraph">
    ISAAR was founded with a bold vision — to become India’s most trusted drone and robotics training center, delivering high-quality, industry-ready education to the next generation of pilots, engineers, and innovators.
  </p>

  <p className="journey-paragraph">
    Though we are a newly established institution, our foundation is built by passionate aerospace professionals and certified trainers. We've already begun making an impact through hands-on drone pilot training, community workshops, and real-world project deployments.
  </p>

  <p className="journey-paragraph">
    With state-of-the-art labs, DGCA-approved courses, and a fast-growing student community, ISAAR is quickly becoming a name to watch in the drone technology space.
  </p>

  <p className="journey-paragraph highlight">
    Our journey is just beginning — and you're invited to be a part of it.
  </p>
</section>

    </div>
  </div>

  <div className="zigzag-block left" data-aos="fade-up-right">
    <img src={valuesImage} alt="Core Values" className="zigzag-img" />
    <div className="zigzag-text" data-aos="zoom-in-up">
      <h3>Our Core Values</h3>
      <ul className="core-values-list">
      <li>
      <strong>Hands-On Learning:</strong> Real flight training right from day one
    </li>
    <li>
      <strong>Integrity & Safety:</strong> Compliance with DGCA standards and best practices
    </li>
    <li>
      <strong>Industry Relevance:</strong> Curriculum shaped by real-world applications
    </li>
    <li>
      <strong>Career Support:</strong> 100% placement assistance and mentorship
    </li>
     </ul>
    </div>
  </div>
</section>


  </>
);

export default About;
