import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import './TaskOverviewSection.css';

const TaskOverviewSection = () => {
  const [overview, setOverview] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [newTask, setNewTask] = useState({
    employee_id: '',
    title: '',
    description: ''
  });

  const token = localStorage.getItem('token');

  const fetchOverview = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/tasks/overview', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setOverview(res.data);
    } catch (err) {
      console.error('Failed to fetch task overview:', err);
    }
  }, [token]);

  const fetchEmployees = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/employees', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEmployees(res.data);
    } catch (err) {
      console.error('Failed to fetch employees:', err);
    }
  }, [token]);

  useEffect(() => {
    fetchOverview();
    fetchEmployees();
  }, [fetchOverview, fetchEmployees]);

  const handleTaskAssign = async () => {
    if (!newTask.employee_id || !newTask.title) {
      alert('Please select employee and enter task title');
      return;
    }

    try {
      await axios.post('http://localhost:5000/api/tasks/assign', {
        employee_id: newTask.employee_id,
        title: newTask.title,
        description: newTask.description
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      alert('✅ Task assigned successfully');
      setNewTask({ employee_id: '', title: '', description: '' });
      fetchOverview();
    } catch (err) {
      console.error('Error assigning task:', err);
      alert('❌ Failed to assign task');
    }
  };

  return (
    <div className="task-overview-section">
      <h3>🧾 Task Overview per Employee</h3>

      <div className="task-form">
        <h4>Assign Task</h4>
        <select
          value={newTask.employee_id}
          onChange={(e) => setNewTask({ ...newTask, employee_id: e.target.value })}
        >
          <option value="">Select Employee</option>
          {employees.map((emp) => (
            <option key={emp.id} value={emp.id}>{emp.name}</option>
          ))}
        </select>

        <input
          type="text"
          placeholder="Task Title"
          value={newTask.title}
          onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
        />

        <textarea
          placeholder="Task Description (optional)"
          value={newTask.description}
          onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
        />

        <button onClick={handleTaskAssign}>Assign Task</button>
      </div>

      {overview.length === 0 ? (
        <p>No task data available.</p>
      ) : (
        <div className="responsive-table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Employee</th>
                <th>Total</th>
                <th>Completed</th>
                <th>In Progress</th>
                <th>Pending</th>
              </tr>
            </thead>
            <tbody>
              {overview.map(emp => (
                <tr key={emp.employee_id}>
                  <td>{emp.employee_name}</td>
                  <td>{emp.total_tasks}</td>
                  <td>{emp.completed_tasks}</td>
                  <td>{emp.in_progress_tasks}</td>
                  <td>{emp.pending_tasks}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default TaskOverviewSection;
