import './Footer.css';
import PrivacyPolicy from './PrivacyPolicy';
import { FaFacebook, FaInstagram, FaLinkedin } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Footer = ({ setCurrentSection }) => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="contact-section">
          <div className="contact-container">
            <div className="contact-left">
              <h2>Get in Touch</h2>
            </div>
            <div className="contact-right">
              <h3>Visit Us</h3>
              <p>Reach Out to Us Today</p>
              <a
                href="https://www.instagram.com/_isar_25?igsh=MTR6OWFrd2V6dWs5Zw=="
                target="_blank"
                rel="noopener noreferrer"
              >
                Subscribe
              </a>
              <p>Connect</p>
            </div>
          </div>

          <Link to="/contact" className="contact-btn">
            Contact Us
          </Link>
        </div>

        <div className="footer-links">
          <PrivacyPolicy />
        </div>

        <div className="footer-icons">
          <a
            href="https://www.instagram.com/_isar_25?igsh=MTR6OWFrd2V6dWs5Zw=="
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
          >
            <FaInstagram size={20} />
          </a>
          <a
            href="https://www.linkedin.com/company/indian-scientific-aerospace-and-robotics/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
          >
            <FaLinkedin size={20} />
          </a>
          <a
            href="https://www.facebook.com/share/16n143NgEy/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook"
          >
            <FaFacebook size={20} />
          </a>
        </div>

        <p className="footer-copy">&copy; {new Date().getFullYear()} <a href="https://isaar.in">www.isaar.in</a></p>
      </div>
    </footer>
  );
};

export default Footer;
